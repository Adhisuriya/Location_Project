<?php
// setting time zone
date_default_timezone_set("Asia/Kolkata");

// define the site root
define('SITE_ROOT', 'http://localhost/ample/');



// Database Information
// Database Hostname
define('DATABASE_HOST','localhost');
// Database Username
define('DATABASE_USER','root');
// Database Name
define('DATABASE_NAME', 'ample');
// Database DB_PASS
define('DATABASE_PASS','');


 ?>
